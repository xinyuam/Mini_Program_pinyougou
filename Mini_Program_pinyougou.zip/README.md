# Mini_Program_pinyougou
零基础(会html，css)学习黑马的小程序课程写的微信小程序！<br>
边看教程写小程序，边补习js。<br>
教程视频链接：https://www.bilibili.com/video/av73342655 <br>
黑马程序员官网链接：http://yun.itheima.com/course/589.html<br>